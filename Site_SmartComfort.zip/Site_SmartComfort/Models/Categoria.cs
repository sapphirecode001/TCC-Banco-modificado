﻿namespace Site_SmartComfort.Models
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string NomeCategoria { get; set; }
    }
}
